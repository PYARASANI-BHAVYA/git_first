package com.catrionbe.api.model;

public class UserIdRequest {

	public UserIdRequest() {
		
	}
	private int userId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
}
